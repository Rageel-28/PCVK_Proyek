# Alfamart Indomaret Struk > 2025-07-01 6:32pm
https://universe.roboflow.com/jupar/alfamart-indomaret-struk-hjhso

Provided by a Roboflow user
License: CC BY 4.0

