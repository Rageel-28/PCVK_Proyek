# Receipt Indomaret > 2025-07-01 1:10pm
https://universe.roboflow.com/jupar/receipt-indomaret-zdpdk

Provided by a Roboflow user
License: CC BY 4.0

